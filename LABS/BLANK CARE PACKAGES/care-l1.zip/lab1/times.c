
// Lab 1: subroutine times(x,y)

int times(int x, int y) {
    int result = x * y;
    return result;
}

