
int sum_unrolled(int *A, int n) {
    /*
    // 2x1a, 2x2 unrolling
     int total[2] = {0, 0};
    int i;
    int ret = 0;
    for (i = 0; i < n-2; i += 2) {
        //total[0] += A[i];
        //total[1] += A[i+1];
        ret += (A[i] + A[i+1]);
    }
    for (; i < n; i++) {
        ret += A[i];
    }
    //ret += total[0];
    //ret += total[1];
    return ret;
    */

    // 4x1a, 4x4 unrolling
    int total[4] = {0, 0, 0, 0};
    int i;
    int ret = 0;
    for (i = 0; i < n-4; i += 4) {
        ret += (A[i] + A[i+1]) + (A[i+2] + A[i+3]);
        //total[0] += A[i];
        //total[1] += A[i+1];
        //total[2] += A[i+2];
        //total[3] += A[i+3];
    }
    for (; i < n; i++) {
        ret += A[i];
    }
    //ret += total[0];
    //ret += total[1];
    //ret += total[2];
    //ret += total[3];
    return ret;
}


int sum_rolled(int *A, int n) {
    int total = 0;
    int i;
    for (i = 0; i < n; i++) {
        total += A[i];
    }
    return total;
}


